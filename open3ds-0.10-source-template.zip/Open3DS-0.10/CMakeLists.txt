cmake_minimum_required(VERSION 3.20)
project(Mali3DS VERSION 0.1.0 LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

add_library(mali3ds_core
    core/src/game_file.cpp
)
target_include_directories(mali3ds_core PUBLIC core/include)

add_executable(mali3ds desktop/main.cpp)
target_link_libraries(mali3ds PRIVATE mali3ds_core)

if(MSVC)
  target_compile_options(mali3ds_core PRIVATE /W4 /permissive-)
  target_compile_options(mali3ds PRIVATE /W4 /permissive-)
else()
  target_compile_options(mali3ds_core PRIVATE -Wall -Wextra -Wpedantic)
  target_compile_options(mali3ds PRIVATE -Wall -Wextra -Wpedantic)
endif()
