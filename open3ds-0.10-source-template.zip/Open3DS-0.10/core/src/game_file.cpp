#include "mali3ds/game_file.hpp"
#include <algorithm>
#include <cctype>
#include <system_error>

namespace mali3ds {
namespace {
std::string lower(std::string value) {
    std::transform(value.begin(), value.end(), value.begin(),
        [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return value;
}
}

const char* kind_name(GameFileKind kind) noexcept {
    switch (kind) {
        case GameFileKind::Ctr3ds: return ".3ds";
        case GameFileKind::CtrCci: return ".cci";
        case GameFileKind::CtrCia: return ".cia";
        default: return "desconhecido";
    }
}

GameFileInfo inspect_game_file(const std::filesystem::path& path) {
    GameFileInfo result;
    result.path = path;
    std::error_code ec;
    result.exists = std::filesystem::is_regular_file(path, ec);
    if (ec || !result.exists) {
        result.message = "O caminho não existe ou não é um ficheiro regular.";
        return result;
    }

    result.size = std::filesystem::file_size(path, ec);
    if (ec || result.size == 0) {
        result.message = "Não foi possível ler o tamanho ou o ficheiro está vazio.";
        return result;
    }

    const auto ext = lower(path.extension().string());
    if (ext == ".3ds") result.kind = GameFileKind::Ctr3ds;
    else if (ext == ".cci") result.kind = GameFileKind::CtrCci;
    else if (ext == ".cia") result.kind = GameFileKind::CtrCia;

    result.message = result.kind == GameFileKind::Unknown
        ? "Extensão não reconhecida. Nenhum conteúdo foi carregado."
        : "Extensão reconhecida; o protótipo não consegue ainda executar jogos.";
    return result;
}
}
