#pragma once
#include <filesystem>
#include <string>

namespace mali3ds {
enum class GameFileKind { Ctr3ds, CtrCci, CtrCia, Unknown };

struct GameFileInfo {
    std::filesystem::path path;
    GameFileKind kind{GameFileKind::Unknown};
    bool exists{false};
    std::uintmax_t size{0};
    std::string message;
};

// Only checks file existence, size and extension. It does not parse, decrypt,
// authenticate, or execute game content.
GameFileInfo inspect_game_file(const std::filesystem::path& path);
const char* kind_name(GameFileKind kind) noexcept;
}
