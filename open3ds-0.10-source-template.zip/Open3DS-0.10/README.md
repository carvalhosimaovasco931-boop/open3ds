# Open3DS 0.10 — protótipo de código aberto

**Versão:** 0.10-dev  
**Estado:** esqueleto de aplicação / não é ainda um emulador funcional.

Este repositório é um ponto de partida multiplataforma para um projeto de emulação 3DS.
Não contém um núcleo de emulação, firmware, chaves, BIOS, jogos nem código extraído de
outros emuladores. Por isso, nesta versão, **não executa jogos**. A interface e o
seletor de ficheiros são apenas a fundação do produto.

## Hardware-alvo

- Android com MediaTek Helio P70, GPU Mali-G72 MP3 e 4 GB RAM.
- Windows x64 para desenvolvimento e testes.

O desempenho real não pode ser garantido apenas pela identificação do SoC. A compatibilidade
dependerá da implementação futura da CPU ARM11/ARM9, GPU PICA200, sistema, áudio,
serviços, formatos de imagem e APIs gráficas.

## Estrutura

- `core/`: interfaces e validação inicial de ficheiros.
- `desktop/`: aplicação de consola mínima para Windows/Linux/macOS.
- `android/`: projeto Android inicial com Kotlin.
- `docs/`: plano técnico.

## Compilar o protótipo desktop

Requisitos: CMake 3.20+ e compilador C++17.

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
```

O executável resultante chama-se `open3ds`. No Windows, o CMake gera a solução adequada
ao compilador instalado. Isto ainda não gera um EXE de emulação.

## Android

Abrir a pasta `android/` no Android Studio e sincronizar o Gradle. É necessário instalar
um Android SDK compatível. O projeto cria uma aplicação-base; ainda não inclui um APK
pré-compilado nem um motor de emulação.

## Formatos e legalidade

A extensão de um ficheiro não prova que esteja válido ou desencriptado. O protótipo apenas
reconhece extensões `.3ds`, `.cci` e `.cia`; não interpreta nem desencripta o conteúdo.
Usa apenas cópias de jogos e dados de sistema que tenhas direito a utilizar, respeitando
a legislação aplicável. Não distribuímos jogos, firmware ou chaves.

## Próximas etapas reais

1. Definir uma arquitetura de CPU ARM11/ARM9 e testes de instruções.
2. Implementar memória, interrupções, temporizadores e DMA.
3. Implementar GPU PICA200 e um backend gráfico (Vulkan/OpenGL ES).
4. Implementar serviços do sistema, armazenamento, áudio e entrada.
5. Implementar carregadores e formatos de forma compatível e legal.
6. Criar testes de compatibilidade e medir desempenho no Helio P70.
