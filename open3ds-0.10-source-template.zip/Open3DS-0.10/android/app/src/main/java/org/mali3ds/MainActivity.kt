package org.mali3ds

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }
        val title = TextView(this).apply {
            text = "Mali3DS 0.1.0-dev"
            textSize = 26f
            gravity = Gravity.CENTER
        }
        val status = TextView(this).apply {
            text = "Protótipo Android\\n\\nO núcleo de emulação 3DS ainda não está implementado.\\nEsta versão não executa jogos."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        layout.addView(title)
        layout.addView(status)
        setContentView(layout)
    }
}
