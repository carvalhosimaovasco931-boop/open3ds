#include "mali3ds/game_file.hpp"
#include <iostream>

int main(int argc, char** argv) {
    std::cout << "Mali3DS 0.1.0-dev — protótipo\n";
    std::cout << "Ainda não contém um núcleo de emulação 3DS.\n\n";
    if (argc < 2) {
        std::cout << "Utilização: mali3ds <ficheiro.3ds|.cci|.cia>\n";
        return 0;
    }

    const auto info = mali3ds::inspect_game_file(argv[1]);
    std::cout << "Ficheiro: " << info.path.string() << '\n';
    std::cout << "Existe: " << (info.exists ? "sim" : "não") << '\n';
    if (info.exists) {
        std::cout << "Tamanho: " << info.size << " bytes\n";
        std::cout << "Tipo reconhecido: " << mali3ds::kind_name(info.kind) << '\n';
    }
    std::cout << info.message << '\n';
    return info.exists ? 0 : 1;
}
