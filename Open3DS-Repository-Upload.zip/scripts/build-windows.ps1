$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$build = Join-Path $root "build-windows"
$stage = Join-Path $root "open3ds-0.10-windows-x86_64"

cmake -S $root -B $build -A x64
cmake --build $build --config Release

$exe = Get-ChildItem $build -Filter "*.exe" -Recurse |
  Where-Object { $_.Name -match "mali3ds|open3ds" } |
  Select-Object -First 1
if (-not $exe) { throw "Executável não encontrado." }

if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
New-Item -ItemType Directory -Force "$stage/dist" | Out-Null
New-Item -ItemType Directory -Force "$stage/plugins" | Out-Null
New-Item -ItemType Directory -Force "$stage/scripting" | Out-Null
Copy-Item $exe.FullName "$stage/Open3DS.exe"
"Open3DS 0.10-dev — protótipo; ainda não executa jogos 3DS." |
  Set-Content "$stage/README.txt"
Compress-Archive -Path $stage -DestinationPath (Join-Path $root "open3ds-0.10-windows-x86_64.zip") -Force
Write-Host "ZIP criado. Este protótipo não é um emulador funcional."
